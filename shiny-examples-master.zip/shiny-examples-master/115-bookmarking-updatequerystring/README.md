This app demonstrates bookmarking with the state encoded in the URL, and updates the browser's location bar automatically each time an input value changes.
