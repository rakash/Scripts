This example shows two ways to add progress bars to an app.

One method is to use `withProgress()`, and another is to create a `Progress` object using `shiny::Progress$new()`. The latter allows finer control over the progress bar, but it is a bit more complicated to use.