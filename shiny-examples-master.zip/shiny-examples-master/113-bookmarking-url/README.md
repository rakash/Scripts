This app demonstrates bookmarking with the state encoded in the URL.
